# bre01-blog-secu
The is a demo blog project that demonstrates how to patch SQL, XSS, strong auth and CSRF security concerns. The blog is in PHP using MVC design pattern and OOP.
